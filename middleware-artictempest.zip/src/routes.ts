import { Router } from "express";
import authRoutes from "./routes/auth";
import userRoutes from "./routes/users";
import characterRoutes from "./routes/characters";

const router = Router();

// ✅ Definir rutas principales correctamente
router.use("/auth", authRoutes);
router.use("/users", userRoutes);
router.use("/characters", characterRoutes);

// ✅ Exportar el enrutador principal
export default router;
