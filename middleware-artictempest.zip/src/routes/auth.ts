import express, { Request, Response } from 'express';
import crypto from 'crypto';
import {
  getBattleNetAuthUrl,
  getBattleNetToken,
  getBattleNetUser,
  getCharactersFromBattleNet, // 🔹 Obtiene personajes de Battle.net
  getDiscordAuthUrl,
  getDiscordToken,
  getDiscordUser,
  verifyToken
} from '../services/authService';
import prisma from '../prisma';
import jwt from 'jsonwebtoken';

const router = express.Router();
const stateStore = new Map<string, string>(); // Almacena los estados temporales para evitar ataques CSRF

// 🔹 Generar un token JWT
const generateJWT = (user: {
  id: number;
  username: string;
  discordId?: string;
  battleNetId?: number;
}): string => {
  if (!process.env.JWT_SECRET) {
    console.error('❌ JWT_SECRET no está definido en .env');
    throw new Error('Configuración de JWT inválida');
  }

  return jwt.sign(
    {
      userId: user.id,
      username: user.username,
      discordId: user.discordId || undefined,
      battleNetId: user.battleNetId || undefined
    },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// 🔹 Login con Battle.net
router.get('/battle-net', (req: Request, res: Response) => {
  const state = crypto.randomBytes(16).toString('hex');
  const token = req.query.token as string | undefined;

  if (!token) {
    return res.status(400).json({ error: 'Token de sesión faltante' });
  }

  stateStore.set(state, token);
  return res.redirect(getBattleNetAuthUrl(state));
});

// 🔹 Callback de Battle.net
router.get('/battle-net/callback', async (req: Request, res: Response) => {
  const code = req.query.code as string | undefined;
  const state = req.query.state as string | undefined;

  if (!code || !state || !stateStore.has(state)) {
    return res.status(400).json({ error: 'Código de autorización o state inválido' });
  }

  const token = stateStore.get(state) || '';
  stateStore.delete(state);

  try {
    const decoded = verifyToken(token);
    if (!decoded || !decoded.userId) {
      return res.status(401).json({ error: 'Token inválido o expirado' });
    }

    const accessToken = await getBattleNetToken(code);
    const userInfo = await getBattleNetUser(accessToken);
    const battleNetId = Number(userInfo.id); // 🔹 Convertir a número explícitamente

    if (isNaN(battleNetId)) {
      throw new Error('El ID de Battle.net no es un número válido.');
    }

    let user = await prisma.user.findUnique({
      where: { id: decoded.userId }
    });

    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado en la base de datos' });
    }

    user = await prisma.user.update({
      where: { id: user.id },
      data: { battleNetId, username: userInfo.battletag }
    });

    // 🔹 Obtener personajes de Battle.net y guardarlos en la base de datos
    const characters = await getCharactersFromBattleNet(accessToken);
    if (characters.length > 0) {
      await prisma.character.createMany({
        data: characters.map((char) => ({
          userId: user!.id, // 🔹 TypeScript ya sabe que user no es `null`
          name: char.name,
          realm: char.realm,
          region: 'eu',
          class: char.class.toString(), // 🔹 Convertir a string si es necesario
          ilvl: Number(char.ilvl) || 0, // 🔹 Asegurar que es un número
          mythicScore: char.mythicScore ? Number(char.mythicScore) : 0 // 🔹 Evitar valores `undefined`
        })),
        skipDuplicates: true // 🔹 Evita duplicados
      });
    }

    const newToken = generateJWT({
      id: user.id,
      username: user.username,
      discordId: user.discordId || undefined,
      battleNetId: user.battleNetId || undefined
    });

    const frontendUrl = process.env.FRONTEND_URL?.trim() || 'http://localhost:8080';
    return res.redirect(`${frontendUrl}/dashboard?token=${newToken}`);
  } catch (error) {
    console.error('❌ Error en Battle.net Callback:', error);
    return res.status(500).json({ error: 'Error autenticando con Battle.net' });
  }
});

// 🔹 Login con Discord
router.get('/discord', (req: Request, res: Response) => {
  const state = crypto.randomBytes(16).toString('hex');
  stateStore.set(state, 'valid');
  res.redirect(getDiscordAuthUrl(state));
});

// 🔹 Callback de Discord
router.get('/discord/callback', async (req: Request, res: Response) => {
  const code = req.query.code as string | undefined;
  const state = req.query.state as string | undefined;

  if (!code || !state || !stateStore.has(state)) {
    return res.status(400).json({ error: 'Código de autorización o state inválido' });
  }

  stateStore.delete(state);

  try {
    const accessToken = await getDiscordToken(code);
    const userInfo = await getDiscordUser(accessToken);

    const user = await prisma.user.upsert({
      where: { discordId: userInfo.id },
      update: { username: userInfo.username },
      create: {
        discordId: userInfo.id,
        battleNetId: undefined,
        username: userInfo.username
      }
    });

    const token = generateJWT({
      id: user.id,
      username: user.username,
      discordId: user.discordId || undefined,
      battleNetId: user.battleNetId || undefined
    });

    const frontendUrl = process.env.FRONTEND_URL?.trim() || 'http://localhost:8080';
    return res.redirect(`${frontendUrl}/dashboard?token=${token}`);
  } catch (error) {
    console.error('❌ Error en Discord Callback:', error);
    return res.status(500).json({ error: 'Error autenticando con Discord' });
  }
});

// 🔹 Verificar usuario con JWT
router.get('/me', async (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'Token no proporcionado' });

  try {
    const token = authHeader.split(' ')[1];
    const decoded = verifyToken(token);

    if (!decoded || !decoded.userId)
      return res.status(401).json({ error: 'Token inválido o expirado' });

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId }
    });
    if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });

    return res.json({ user });
  } catch (error) {
    console.error('❌ Error verificando usuario:', error);
    return res.status(500).json({ error: 'Error al verificar usuario' });
  }
});

// ✅ Exportar el router correctamente
export default router;
