import express, { Request, Response } from "express";
import { getCharactersByUser, addCharacter, syncCharacters } from "../services/characterService";
import { body, param, validationResult } from "express-validator";
import prisma from "../prisma";

const router = express.Router();

// ✅ Obtener personajes de un usuario por `userId`
router.get(
  "/user/:userId",
  param("userId").isInt().withMessage("userId debe ser un número válido"),
  async (req: Request, res: Response) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const userId = parseInt(req.params.userId, 10);
      const characters = await getCharactersByUser(userId);

      if (!characters || characters.length === 0) {
        return res.status(404).json({ error: "No se encontraron personajes para este usuario" });
      }

      return res.json(characters);
    } catch (error) {
      console.error("❌ Error obteniendo personajes:", error);
      return res.status(500).json({ error: "Error interno del servidor" });
    }
  }
);


// ✅ Agregar un personaje manualmente
router.post(
  "/",
  [
    body("userId").isInt().withMessage("userId debe ser un número"),
    body("name").isString().notEmpty().withMessage("name es obligatorio"),
    body("realm").isString().notEmpty().withMessage("realm es obligatorio"),
    body("region").isString().notEmpty().withMessage("region es obligatoria"),
    body("className").isString().notEmpty().withMessage("className es obligatorio"),
    body("ilvl").isInt().withMessage("ilvl debe ser un número"),
    body("mythicScore").optional().isInt().withMessage("mythicScore debe ser un número"),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { userId, name, realm, region, className, ilvl, mythicScore, updatedAt } = req.body;

      // Verificar si el usuario existe
      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!user) {
        return res.status(404).json({ error: "Usuario no encontrado" });
      }

      const newCharacter = await addCharacter(userId, name, realm, region, className, ilvl, mythicScore || 0, updatedAt);
      return res.status(201).json(newCharacter); // ✅ SE AÑADE `return`
    } catch (error) {
      console.error("❌ Error agregando personaje:", error);
      return res.status(500).json({ error: "Error interno del servidor" });
    }
  }
);

// ✅ Sincronizar personajes con Battle.net
router.post(
  "/sync",
  [
    body("userId").isInt().withMessage("userId debe ser un número"),
    body("characters").isArray().withMessage("characters debe ser un array válido"),
  ],
  async (req: Request, res: Response) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { userId, characters } = req.body;

      // Verificar si el usuario existe
      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!user) {
        return res.status(404).json({ error: "Usuario no encontrado" });
      }

      if (characters.length === 0) {
        return res.status(400).json({ error: "No se enviaron personajes para sincronizar" });
      }

      const syncedCharacters = await syncCharacters(userId, characters);
      return res.json({ message: "Personajes sincronizados correctamente", syncedCharacters }); // ✅ SE AÑADE `return`
    } catch (error) {
      console.error("❌ Error sincronizando personajes:", error);
      return res.status(500).json({ error: "Error interno del servidor" });
    }
  }
);

export default router;
