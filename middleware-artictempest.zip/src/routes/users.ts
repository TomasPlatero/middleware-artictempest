import express, { Request, Response } from "express";
import { createUser } from "../services/userService";

const router = express.Router();

router.post("/", async (req: Request, res: Response) => {
  const { discordId, battleNetId, username } = req.body;
  try {
    const user = await createUser(discordId, battleNetId, username);
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: "Error creando usuario" });
  }
});

export default router;
